# Weltall / Raumstation
execute as @a[x=1,y=1,z=1,distance=..500] run attribute @s minecraft:gravity base set 0.008

# Mond-Sektor
execute as @a[x=1000,y=5,z=1000,distance=..10000] run attribute @s minecraft:gravity base set 0.014

# Mars-Sektor
execute as @a[x=2000,y=80,z=0,distance=..150] run attribute @s minecraft:gravity base set 0.03

effect give @a minecraft: